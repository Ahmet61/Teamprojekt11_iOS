//
//  ViewController.swift
//  Bildbereich
//
//  Created by Niklas on 30.11.19.
//  Copyright © 2019 Nikals Röske. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var SIZE : CGFloat = 20/2
    var HEIGHT : CGFloat = 320
    var WIDTH : CGFloat = 240
    
    
    @IBOutlet weak var Bildbereich: UIView!
    @IBOutlet weak var obenLinks: UIView!
    @IBOutlet weak var untenLinks: UIView!
    @IBOutlet weak var untenRechts: UIView!
    @IBOutlet weak var obenRechts: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func bildbereichGroesse(){
        HEIGHT = Bildbereich.frame.size.height
        WIDTH = Bildbereich.frame.size.width
    }
    
    @IBAction func handlePan(recognizer:UIPanGestureRecognizer) {
        let translation = recognizer.translation(in: self.view)
        if let view = recognizer.view {
            bildbereichGroesse()
            var x = view.center.x + translation.x
            var y = view.center.y + translation.y
            
            var MIN_VALUE : CGFloat
            var MAX_VALUE_HEIGHT : CGFloat
            var MAX_VALUE_WIDTH : CGFloat
            
            MIN_VALUE = (0 + SIZE)
            MAX_VALUE_WIDTH = (WIDTH - SIZE)
            MAX_VALUE_HEIGHT = (HEIGHT - SIZE)
            
            let yKleiner = (y < MIN_VALUE)
            let yGroeßer = (y > MAX_VALUE_HEIGHT)
            
            let xKleiner = (x < MIN_VALUE)
            let xGroeßer = (x > MAX_VALUE_WIDTH)
            
            print("X:  \(x)")
            print("Y:  \(y)")
            
            if(yKleiner){
                y = MIN_VALUE
            }else if(yGroeßer){
                y = MAX_VALUE_HEIGHT
            }
            
            if(xKleiner){
                x = MIN_VALUE
            }else if(xGroeßer){
                x = MAX_VALUE_WIDTH
            }
            /*
            if (!yKleiner && !yGroeßer && !xGroeßer && !xKleiner){
                view.center = CGPoint(
                    x:view.center.x + translation.x,
                    y:view.center.y + translation.y)
                print("Alles im Rahmen")
            }else{
                if(xKleiner){
                    if(yKleiner){
                        print("xKleiner und yKleienr")
                        view.center = CGPoint(
                            x:MIN_VALUE,
                            y:MIN_VALUE)
                    }else if(yGroeßer){
                        print("xKleiner und yGrößer")
                        view.center = CGPoint(
                            x:MIN_VALUE,
                            y:MAX_VALUE_HEIGHT)
                    }else{
                        print("xKleiner")
                        view.center = CGPoint(
                            x:MIN_VALUE,
                            y:view.center.y + translation.y)
                    }
                }else if(yKleiner){
                    if(xGroeßer){
                        print("xGroeßer und yKleienr")
                        view.center = CGPoint(
                            x:MAX_VALUE_WIDTH,
                            y:MIN_VALUE)
                    }else{
                        print("yKleienr")
                        view.center = CGPoint(
                            x:view.center.x + translation.x,
                            y:MIN_VALUE)
                    }
                }else if(xGroeßer){
                    if(yGroeßer){
                        print("xGroeßer und yGroeßer")
                        view.center = CGPoint(
                            x:MAX_VALUE_WIDTH,
                            y:MAX_VALUE_HEIGHT)
                    }else{
                        print("xGroeßer")
                        view.center = CGPoint(
                            x:MAX_VALUE_WIDTH,
                            y:view.center.y + translation.y)
                    }
                }else if(yGroeßer){
                    print("yGroeßer")
                    view.center = CGPoint(
                        x:view.center.x + translation.x,
                        y:MAX_VALUE_HEIGHT)
                }
            }
            */
            view.center = CGPoint(x:x, y:y)
            setPartnerPositions(name: view, x: x, y: y)
        }
        
        recognizer.setTranslation(CGPoint.zero, in: self.view)
    }

    func setPartnerPositions(name: UIView, x: CGFloat, y: CGFloat){
        switch (name){
        case obenLinks:
            untenLinks.center = CGPoint(x: x, y: untenLinks.center.y)
            obenRechts.center = CGPoint(x: obenRechts.center.x, y:y)
            break;
        case untenLinks:
            obenLinks.center = CGPoint(x: x, y: obenLinks.center.y)
            untenRechts.center = CGPoint(x: untenRechts.center.x, y:y)
            break;
        case untenRechts:
            obenRechts.center = CGPoint(x: x, y: obenRechts.center.y)
            untenLinks.center = CGPoint(x: untenLinks.center.x, y: y)
            break;
        case obenRechts:
            obenLinks.center = CGPoint(x: obenLinks.center.x, y: y)
            untenRechts.center = CGPoint(x: x, y: untenRechts.center.y)
            break;
        default:
            break;
        }
        partnerDistanceControl(name: name);
    }
    
    func partnerDistanceControl(name: UIView){
        let size = SIZE*2
        switch (name){
            case obenLinks:
                if(untenLinks.center.y - obenLinks.center.y < size){
                    obenLinks.center = CGPoint(x:obenLinks.center.x, y: untenLinks.center.y-size)
                    obenRechts.center = CGPoint(x: obenRechts.center.x, y: untenLinks.center.y-size)
                }
                if(obenRechts.center.x - obenLinks.center.x < size){
                    obenLinks.center = CGPoint(x:obenRechts.center.x - size, y: obenLinks.center.y)
                    untenLinks.center = CGPoint(x: obenRechts.center.x - size, y: untenLinks.center.y)
                }

                break;
            
            case untenLinks:
                if(untenLinks.center.y - obenLinks.center.y < size){
                    untenLinks.center.y = obenLinks.center.y + size
                    untenRechts.center.y = untenLinks.center.y
                }

                if(untenRechts.center.x - untenLinks.center.x < size){
                    untenLinks.center.x = untenRechts.center.x - size
                    obenLinks.center.x = untenLinks.center.x
                }
                break;
            
            case untenRechts:
                if(untenRechts.center.y - obenRechts.center.y < size){
                    untenRechts.center.y = obenRechts.center.y + size
                    untenLinks.center.y = untenRechts.center.y
                }

                if(untenRechts.center.x - untenLinks.center.x < size){
                    untenRechts.center.x = untenLinks.center.x + size
                    obenRechts.center.x = untenRechts.center.x
                }
                break;
            
            case obenRechts:
                if(untenRechts.center.y - obenRechts.center.y < size){
                    obenRechts.center.y = untenRechts.center.y - size
                    obenLinks.center.y = obenRechts.center.y
                }

                if(obenRechts.center.x - obenLinks.center.x < size){
                    obenRechts.center.x = obenLinks.center.x + size
                    untenRechts.center.x = obenRechts.center.x
                }
                break;
 
        default:
            break;
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

