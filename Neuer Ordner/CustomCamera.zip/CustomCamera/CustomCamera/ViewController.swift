//
//  ViewController.swift
//  CustomCamera
//
//  Created by Brian Advent on 24/01/2017.
//  Copyright © 2017 Brian Advent. All rights reserved.
//

import UIKit
import AVFoundation
import Darwin
import Dispatch


class ViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {

    let captureSession = AVCaptureSession()
    var previewLayer:CALayer!
    
    var counter = 0
    
    var captureDevice:AVCaptureDevice!
    
    var takePhoto = false
    
    var altSeconds = -1
    var mSeconds = 0
    
    var FOLDER_NAME = "Projekt"
    var FOLDER_NAME_Bilder = "Bilder"
    var FOLDER_NAME_JSON = "JSONS"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        listFilesFromDocumentsFolder()
        delete()
        listFilesFromDocumentsFolder()
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        prepareCamera()
    }
    
    
    func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
        let size = image.size
        
        let widthRatio  = targetSize.width  / size.width
        let heightRatio = targetSize.height / size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio,  height: size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        //let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)
        let rect = CGRect(x: 0, y: 0, width: targetSize.width, height: targetSize.height)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }
    
    func prepareCamera() {
        captureSession.sessionPreset = AVCaptureSessionPresetPhoto
        
        if let availableDevices = AVCaptureDeviceDiscoverySession(deviceTypes: [.builtInWideAngleCamera], mediaType: AVMediaTypeVideo, position: .back).devices {
            captureDevice = availableDevices.first
            beginSession()
        }
        
    }
    
    func beginSession () {
        do {
            let captureDeviceInput = try AVCaptureDeviceInput(device: captureDevice)
            
            captureSession.addInput(captureDeviceInput)
            
        }catch {
            print(error.localizedDescription)
        }
        
        
        if let previewLayer = AVCaptureVideoPreviewLayer(session: captureSession) {
            self.previewLayer = previewLayer
            self.view.layer.addSublayer(self.previewLayer)
            self.previewLayer.frame = self.view.layer.frame
            captureSession.startRunning()
            
            let dataOutput = AVCaptureVideoDataOutput()
            dataOutput.videoSettings = [(kCVPixelBufferPixelFormatTypeKey as NSString):NSNumber(value:kCVPixelFormatType_32BGRA)]
            
            dataOutput.alwaysDiscardsLateVideoFrames = true
            
            if captureSession.canAddOutput(dataOutput) {
                captureSession.addOutput(dataOutput)
            }
            
            captureSession.commitConfiguration()
            
            
            let queue = DispatchQueue(label: "de.team11.captureQueue")
            dataOutput.setSampleBufferDelegate(self, queue: queue)
            
            
        
        }
        
    }
    
    
    func listFilesFromDocumentsFolder()    {
        let fileMngr = FileManager.default
        do {
            if let docs = fileMngr.urls(for: .documentDirectory, in: .userDomainMask).first {
                let filePath =  docs.appendingPathComponent("\(FOLDER_NAME)/\(FOLDER_NAME_Bilder)")
                do{
                    try print(fileMngr.contentsOfDirectory(atPath:filePath.path))
                }catch{
                
                }
            }
        }
        do {
            if let docs = fileMngr.urls(for: .documentDirectory, in: .userDomainMask).first {
                let filePath =  docs.appendingPathComponent("\(FOLDER_NAME)/\(FOLDER_NAME_JSON)")
                do{
                    try print(fileMngr.contentsOfDirectory(atPath:filePath.path))
                }catch{
                    
                }
            }
        }
        // List all contents of directory and return as [String] OR nil if failed
    }
    
    func delete(){
        let fileManager = FileManager.default
        do {
            if let tDocumentDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first {
                let filePath =  tDocumentDirectory.appendingPathComponent("\(FOLDER_NAME)")
                if fileManager.fileExists(atPath: filePath.path) {
                    do {
                        try FileManager.default.removeItem(at: filePath)
                        print("deleted")
                    } catch {
                        print("Couldn't delete document directory")
                    }
                }
                
               
            }
        }
    }
        
        
        
    func savePictureInDocuments(name: String, image: UIImage) -> Bool{
        let fileManager = FileManager.default
        do {
            if let tDocumentDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first {
                var filePath =  tDocumentDirectory.appendingPathComponent("\(FOLDER_NAME)/\(FOLDER_NAME_Bilder)")
                //filePath =  filePath.appendingPathComponent("\(FOLDER_NAME_Bilder)")
                if !fileManager.fileExists(atPath: filePath.path) {
                    do {
                        try fileManager.createDirectory(atPath: filePath.path, withIntermediateDirectories: true, attributes: nil)
                    } catch {
                        print("Couldn't create document directory")
                    }
                }
                
                filePath = filePath.appendingPathComponent("\(name).jpg")
                print("Document directory is \(filePath)")
                if let imageData = UIImageJPEGRepresentation(image, 0.5) {
                    try imageData.write(to: filePath)
                    print("Bild gespeichert")
                    return true
                }
            }
        } catch {
            print(error)
        }
        return false
    }
    
    func saveJsonFileToDocuments(name: String) -> Bool {
        let personArray =  [["person": ["name": "Dani", "age": "24"]], ["person": ["name": "ray", "age": "70"]]]
        let fileManager = FileManager.default
        do {
            if let tDocumentDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first {
                var filePath =  tDocumentDirectory.appendingPathComponent("\(FOLDER_NAME)/\(FOLDER_NAME_JSON)")
                //filePath =  tDocumentDirectory.appendingPathComponent("\(FOLDER_NAME_JSON)")
                if !fileManager.fileExists(atPath: filePath.path) {
                    do {
                        try fileManager.createDirectory(atPath: filePath.path, withIntermediateDirectories: true, attributes: nil)
                    } catch {
                        print("Couldn't create document directory")
                    }
                }
                filePath = filePath.appendingPathComponent("\(name).json")
                print("Document directory is \(filePath)")
                //Speichern
                do {
                    let data = try JSONSerialization.data(withJSONObject: personArray, options: [])
                    try data.write(to: filePath, options: [])
                    print("JSON gespeichert")
                } catch {
                    print(error)
                }
            }
        } catch {
            print(error)
        }
        return false
        
        // Get the url of Persons.json in document directory
        
        
        
        // Transform array into data and save it into file
        
    }
    
    @IBAction func takePhoto(_ sender: Any) {
        //takePhoto = !takePhoto
        takePhoto=true
        counter = 0
        /*
        if !takePhoto{
            let fileManager = FileManager.default
            if let tDocumentDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first {
                let filePath =  tDocumentDirectory.appendingPathComponent("\(FOLDER_NAME)")
                try? FileManager.default.removeItem(atPath: filePath.path)
                print("\(filePath) gelöscht")
            }
        }
        */
    }
    
    
    func cropImage1(image: UIImage, rect: CGRect) -> UIImage {
        let cgImage = image.cgImage! // better to write "guard" in realm app
        let croppedCGImage = cgImage.cropping(to: rect)
        return UIImage(cgImage: croppedCGImage!)
    }
   
    
    
    func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputSampleBuffer sampleBuffer: CMSampleBuffer!, from connection: AVCaptureConnection!) {
        
        if takePhoto {
            takePhoto = false
            
            
            if var image = self.getImageFromSampleBuffer(buffer: sampleBuffer) {
                let date = Date()
                let calendar = Calendar.current
                
                let hour = calendar.component(.hour, from: date)
                let minutes = calendar.component(.minute, from: date)
                let seconds = calendar.component(.second, from: date)
                if seconds == altSeconds{
                    mSeconds = mSeconds + 1
                }else{
                    mSeconds = 1
                    altSeconds=seconds
                }
                print("hours = \(hour):\(minutes):\(seconds):\(mSeconds)")
                
                let photoVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PhotoVC") as! PhotoViewController
                
                
                //image = resizeImage(image: image, targetSize: CGSize(width: 60, height: 160))
                image = cropImage1(image: image, rect: CGRect.init(x: 0, y: 0, width: 100, height: 100))
                photoVC.takenPhoto = image
                writeImage(image: image)
                //save("Hello.png", image: image)
                //savePictureInDocuments(name: "Hello", image: image)
                //saveJsonFileToDocuments(name: "Hello")
                /*
                DispatchQueue.main.async {
                    self.present(photoVC, animated: true, completion: { 
                        self.stopCaptureSession()
                    })
                    
                }
                */
            }
            
        
        }
    }
    
    
    
    func writeImage(image: UIImage) {
        counter = counter+1
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(self.finishWriteImage), nil)
    }
    
    @objc private func finishWriteImage(_ image: UIImage, didFinishSavingWithError error: NSError?, contextInfo: UnsafeRawPointer) {
        if (error != nil) {
            // Something wrong happened.
            print("error occurred: \(String(describing: error))")
        } else {
            // Everything is alright.
            print("\(counter): saved success! ")
        }
    }
    
    func save(_ name: String, image : UIImage) {
        let path: String = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        let url = URL(fileURLWithPath: path).appendingPathComponent(name)
        try! UIImagePNGRepresentation(image)?.write(to: url)
        print("saved image at \(url)")
    }
    
    
    func getImageFromSampleBuffer (buffer:CMSampleBuffer) -> UIImage? {
        if let pixelBuffer = CMSampleBufferGetImageBuffer(buffer) {
            let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
            let context = CIContext()
            
            let imageRect = CGRect(x: 0, y: 0, width: CVPixelBufferGetWidth(pixelBuffer), height: CVPixelBufferGetHeight(pixelBuffer))
            
            if let image = context.createCGImage(ciImage, from: imageRect) {
                return UIImage(cgImage: image, scale: UIScreen.main.scale, orientation: .right)
            }
            
        }
        
        return nil
    }
    
    func stopCaptureSession () {
        self.captureSession.stopRunning()
        
        if let inputs = captureSession.inputs as? [AVCaptureDeviceInput] {
            for input in inputs {
                self.captureSession.removeInput(input)
            }
        }
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

