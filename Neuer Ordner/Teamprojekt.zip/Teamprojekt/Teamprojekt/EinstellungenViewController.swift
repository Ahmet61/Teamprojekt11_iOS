//
//  EinstellungenViewController.swift
//  Teamprojekt
//
//  Created by Niklas on 13.11.19.
//  Copyright © 2019 Team11. All rights reserved.
//

import UIKit

class EinstellungenViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        sliderAnzahlBilder.minimumValue = minSliderAnzahlBilder
        sliderAnzahlBilder.maximumValue = maxSliderAnzahlBilder
        if(contains(key: "anzahlBilderAutonom")){
            updateAnzahlBilderAutonom(value: UserDefaults.standard.value(forKey: "anzahlBilderAutonom") as! Int)
            updateSlider(value: UserDefaults.standard.value(forKey: "anzahlBilderAutonom") as! Int)
        }else{
            updateAnzahlBilderAutonom(value: standardSliderAnzahlBilder)
            updateSlider(value: standardSliderAnzahlBilder)
        }
        
        if(contains(key: "automatischHochladen")){
            automatischHochladen.setOn(UserDefaults.standard.value(forKey: "automatischHochladen") as! Bool, animated: true)
        }else{
            automatischHochladen.setOn(false, animated: true)
        }
        
        if(contains(key: "email")){
            stringEmail.text = UserDefaults.standard.value(forKey: "email") as? String
        }
        
        
        if(contains(key: "passwort")){
            stringPasswort.text = UserDefaults.standard.value(forKey: "passwort") as? String
        }
        
        zahlSliderLinks.text = "" + Int(floor(minSliderAnzahlBilder)).description
        zahlSliderRechts.text = "" + Int(floor(maxSliderAnzahlBilder)).description
        verbunden.text = ""
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Navigation
    @IBOutlet weak var anzahlBilderAutonom: UILabel!
    @IBOutlet weak var zahlSliderLinks: UILabel!
    @IBOutlet weak var zahlSliderRechts: UILabel!
    @IBOutlet weak var sliderAnzahlBilder: UISlider!
    
    var minSliderAnzahlBilder = Float(1)
    var maxSliderAnzahlBilder = Float(50)
    var standardSliderAnzahlBilder = 10
    
    @IBOutlet weak var automatischHochladen: UISwitch!
    
    
    @IBOutlet weak var stringEmail: UITextField!
    @IBOutlet weak var stringPasswort: UITextField!
    @IBOutlet weak var verbunden: UILabel!
    var erfolgreich = "Erfolgreich verbunden"
    var nichtErfolgreich = "Die E-Mail oder das Passwort ist falsch"
    
    
    @IBAction func switchChanged(_ sender: UISwitch) {
        UserDefaults.standard.set(sender.isOn, forKey: "automatischHochladen")
    }
    
    @IBAction func emailEditEnd(_ sender: UITextField) {
        UserDefaults.standard.set(sender.text, forKey: "email")
        tryToConnectGoogleDrive()
    }
    
    @IBAction func passwortEditEnd(_ sender: UITextField) {
        UserDefaults.standard.set(sender.text, forKey: "passwort")
        tryToConnectGoogleDrive()
    }
    
    
    
    
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    
    @IBAction func sliderChanged(_ sender: UISlider) {
        updateAnzahlBilderAutonom(value: Int(floor(sender.value)))
        UserDefaults.standard.set(sender.value, forKey: "anzahlBilderAutonom")
    }
    
    func updateAnzahlBilderAutonom(value: Int){
        if(value==1){
            anzahlBilderAutonom.text = value.description + " Bild die Sekunde"
        }else{
            anzahlBilderAutonom.text = value.description + " Bilder die Sekunde"
        }
    }
    
    func updateSlider(value: Int){
        sliderAnzahlBilder.value = Float(value)
    }
    
    func contains(key: String) -> Bool {
        return UserDefaults.standard.object(forKey: key) != nil
    }
    
    func tryToConnectGoogleDrive(){
        if(stringPasswort.text != "" && stringEmail.text != ""){
            verbunden.text = erfolgreich
        }
    }
    
    
    
    
    
    
    
}
